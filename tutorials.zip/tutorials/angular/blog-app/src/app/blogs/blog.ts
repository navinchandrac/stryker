export class Blog {
    title!: string;
    content!: string;
    createdAt!: Date;
    author!: string ;
}