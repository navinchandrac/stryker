export class Token {
  timestamp: number = 0;
  userId: number = 0;
}
